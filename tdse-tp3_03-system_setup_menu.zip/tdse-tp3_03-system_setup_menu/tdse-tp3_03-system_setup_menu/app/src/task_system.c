/*
 * Copyright (c) 2026 Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @author : Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>
 */

/********************** inclusions *******************************************/
/* Project includes */
#include "main.h"

/* Demo includes */
#include "logger.h"
#include "dwt.h"

/* Application & Tasks includes */
#include "board.h"
#include "app.h"

#include "task_actuator_attribute.h"
#include "task_actuator_interface.h"
#include "task_display_attribute.h"
#include "task_display_interface.h"
#include "task_system_attribute.h"
#include "task_system_interface.h"

#include <stdio.h> // Necesario para usar snprintf (formatear texto)

/* Variables globales de los motores (por defecto ON, 8, L) */
motor_cfg_t g_motors[2] = {
    {1, 8, 0}, // Motor 1
    {1, 8, 0}  // Motor 2
};
/********************** macros and definitions *******************************/
#define DEL_SYS_MIN			0ul
#define DEL_SYS_MED			250ul
#define DEL_SYS_MAX			500ul

/* Modes to excite Task System */
typedef enum task_system_mode {NORMAL, SETUP, MODE_QTY} task_system_mode_t;

#define SYSTEM_DTA_QTY	MODE_QTY

/********************** internal data declaration ****************************/
task_system_dta_t task_system_dta_list[SYSTEM_DTA_QTY];

/********************** internal functions declaration ***********************/
void task_system_normal_statechart(void)
{
    task_system_dta_t *p_task_system_dta = &task_system_dta_list[NORMAL];
    char line1[17], line2[17];

    if (true == any_event_task_system()) {
        p_task_system_dta->flag = true;
        p_task_system_dta->event = get_event_task_system();
    }

    switch (p_task_system_dta->state)
    {
        case ST_SYS_IDLE:
            /* Dibuja la pantalla Main inicial */
            snprintf(line1, 17, "M1:%s %d %c       ", g_motors[0].power?"ON ":"OFF", g_motors[0].speed, g_motors[0].spin?'R':'L');
            snprintf(line2, 17, "M2:%s %d %c       ", g_motors[1].power?"ON ":"OFF", g_motors[1].speed, g_motors[1].spin?'R':'L');
            put_event_task_display(0, 0, line1);
            put_event_task_display(0, 1, line2);

            p_task_system_dta->state = ST_SYS_MAIN;
            break;

        case ST_SYS_MAIN:
            /* Si se presiona ENTER, va al Menu #1 */
            if ((true == p_task_system_dta->flag) && (EV_SYS_ENTER == p_task_system_dta->event))
            {
                p_task_system_dta->flag = false;

                // Preparamos los datos iniciales del menú
                task_system_dta_list[SETUP].state = ST_SYS_MENU_1;
                task_system_dta_list[SETUP].current_motor = 0; // Empieza en Motor 1

                put_event_task_display(0, 0, "Menu #1         ");
                put_event_task_display(0, 1, "> Motor 1       ");

                task_system_set_mode(SETUP);
            }
            else if (p_task_system_dta->flag) {
                p_task_system_dta->flag = false; // Descarta otros botones
            }
            break;

        default:
            p_task_system_dta->state = ST_SYS_IDLE;
            break;
    }
}

void task_system_setup_statechart(void)
{
    task_system_dta_t *p_task_system_dta = &task_system_dta_list[SETUP];
    char display_buffer[17];

    if (true == any_event_task_system()) {
        p_task_system_dta->flag = true;
        p_task_system_dta->event = get_event_task_system();
    }

    if (!p_task_system_dta->flag) return; // Si no hay evento, salimos
    p_task_system_dta->flag = false;      // Consumimos el evento

    switch (p_task_system_dta->state)
    {
        case ST_SYS_MENU_1: // SELECCIONAR MOTOR
            if (EV_SYS_NEXT == p_task_system_dta->event) {
                p_task_system_dta->current_motor = (p_task_system_dta->current_motor + 1) % 2;
                snprintf(display_buffer, 17, "> Motor %d       ", p_task_system_dta->current_motor + 1);
                put_event_task_display(0, 1, display_buffer);
            }
            else if (EV_SYS_ENTER == p_task_system_dta->event) {
                p_task_system_dta->state = ST_SYS_MENU_2;
                p_task_system_dta->current_param = 0; // Empieza en Power
                put_event_task_display(0, 0, "Menu #2         ");
                put_event_task_display(0, 1, "> Power         ");
            }
            else if (EV_SYS_ESCAPE == p_task_system_dta->event) {
                // Volver a Normal (Main)
                task_system_dta_list[NORMAL].state = ST_SYS_IDLE; // Para que redibuje Main
                task_system_set_mode(NORMAL);
            }
            break;

        case ST_SYS_MENU_2: // SELECCIONAR PARÁMETRO
            if (EV_SYS_NEXT == p_task_system_dta->event) {
                p_task_system_dta->current_param = (p_task_system_dta->current_param + 1) % 3;
                if (p_task_system_dta->current_param == 0) put_event_task_display(0, 1, "> Power         ");
                if (p_task_system_dta->current_param == 1) put_event_task_display(0, 1, "> Speed         ");
                if (p_task_system_dta->current_param == 2) put_event_task_display(0, 1, "> Spin          ");
            }
            else if (EV_SYS_ENTER == p_task_system_dta->event) {
                p_task_system_dta->state = ST_SYS_MENU_3;
                put_event_task_display(0, 0, "Menu #3         ");

                // Carga el valor actual a temp_val para editarlo
                if (p_task_system_dta->current_param == 0) {
                    p_task_system_dta->temp_val = g_motors[p_task_system_dta->current_motor].power;
                    put_event_task_display(0, 1, p_task_system_dta->temp_val ? "> ON            " : "> OFF           ");
                }
                else if (p_task_system_dta->current_param == 1) {
                    p_task_system_dta->temp_val = g_motors[p_task_system_dta->current_motor].speed;
                    snprintf(display_buffer, 17, "> %d             ", p_task_system_dta->temp_val);
                    put_event_task_display(0, 1, display_buffer);
                }
                else if (p_task_system_dta->current_param == 2) {
                    p_task_system_dta->temp_val = g_motors[p_task_system_dta->current_motor].spin;
                    put_event_task_display(0, 1, p_task_system_dta->temp_val ? "> RIGHT         " : "> LEFT          ");
                }
            }
            else if (EV_SYS_ESCAPE == p_task_system_dta->event) {
                // Volver a Menu 1
                p_task_system_dta->state = ST_SYS_MENU_1;
                put_event_task_display(0, 0, "Menu #1         ");
                snprintf(display_buffer, 17, "> Motor %d       ", p_task_system_dta->current_motor + 1);
                put_event_task_display(0, 1, display_buffer);
            }
            break;

        case ST_SYS_MENU_3: // MODIFICAR VALOR
            if (EV_SYS_NEXT == p_task_system_dta->event) {
                if (p_task_system_dta->current_param == 0) { // Alternar Power
                    p_task_system_dta->temp_val = !p_task_system_dta->temp_val;
                    put_event_task_display(0, 1, p_task_system_dta->temp_val ? "> ON            " : "> OFF           ");
                }
                else if (p_task_system_dta->current_param == 1) { // Incrementar Speed
                    p_task_system_dta->temp_val = (p_task_system_dta->temp_val + 1) % 10;
                    snprintf(display_buffer, 17, "> %d             ", p_task_system_dta->temp_val);
                    put_event_task_display(0, 1, display_buffer);
                }
                else if (p_task_system_dta->current_param == 2) { // Alternar Spin
                    p_task_system_dta->temp_val = !p_task_system_dta->temp_val;
                    put_event_task_display(0, 1, p_task_system_dta->temp_val ? "> RIGHT         " : "> LEFT          ");
                }
            }
            else if (EV_SYS_ENTER == p_task_system_dta->event) {
                // GUARDAR variables (Save Variables)
                if (p_task_system_dta->current_param == 0) g_motors[p_task_system_dta->current_motor].power = p_task_system_dta->temp_val;
                if (p_task_system_dta->current_param == 1) g_motors[p_task_system_dta->current_motor].speed = p_task_system_dta->temp_val;
                if (p_task_system_dta->current_param == 2) g_motors[p_task_system_dta->current_motor].spin = p_task_system_dta->temp_val;

                // Volver a Menu 2 después de guardar
                p_task_system_dta->state = ST_SYS_MENU_2;
                put_event_task_display(0, 0, "Menu #2         ");
                if (p_task_system_dta->current_param == 0) put_event_task_display(0, 1, "> Power         ");
                if (p_task_system_dta->current_param == 1) put_event_task_display(0, 1, "> Speed         ");
                if (p_task_system_dta->current_param == 2) put_event_task_display(0, 1, "> Spin          ");
            }
            else if (EV_SYS_ESCAPE == p_task_system_dta->event) {
                // DESCARTAR y volver a Menu 2
                p_task_system_dta->state = ST_SYS_MENU_2;
                put_event_task_display(0, 0, "Menu #2         ");
                if (p_task_system_dta->current_param == 0) put_event_task_display(0, 1, "> Power         ");
                if (p_task_system_dta->current_param == 1) put_event_task_display(0, 1, "> Speed         ");
                if (p_task_system_dta->current_param == 2) put_event_task_display(0, 1, "> Spin          ");
            }
            break;

        default:
            p_task_system_dta->state = ST_SYS_MENU_1;
            break;
    }
}

void task_system_set_mode(task_system_mode_t);

/********************** internal data definition *****************************/
const char *p_task_system 		= "Task System (System Statechart)";
const char *p_task_system_ 		= "Non-Blocking Code";
const char *p_task_system__ 	= "(Update by Time Code, period = 1mS)";

/********************** external data declaration ****************************/
task_system_mode_t g_task_system_mode;

/********************** external functions definition ************************/
void task_system_init(void *parameters)
{
	uint32_t index;
	task_system_dta_t 	*p_task_system_dta;
	task_system_st_t	state;
	task_system_ev_t	event;
	bool b_event;

	/* Print out: Task Initialized */
	LOGGER_INFO(" ");
	LOGGER_INFO("  %s is running - Tick [mS] = %lu", GET_NAME(task_system_init), HAL_GetTick());
	LOGGER_INFO("   %s is a %s", GET_NAME(task_system), p_task_system);
	LOGGER_INFO("   %s is a %s", GET_NAME(task_system), p_task_system_);
	LOGGER_INFO("   %s is a %s", GET_NAME(task_system), p_task_system__);

	init_event_task_system();

	task_system_set_mode(NORMAL);

	for (index = 0; SYSTEM_DTA_QTY > index; index++)
	{
		/* Update Task System Data Pointer */
		p_task_system_dta = &task_system_dta_list[index];

		/* Init & Print out: Task execution FSM */
		state = ST_SYS_IDLE;
		p_task_system_dta->state = state;

		event = EV_SYS_IDLE;
		p_task_system_dta->event = event;

		b_event = false;
		p_task_system_dta->flag = b_event;

		LOGGER_INFO(" ");
		LOGGER_INFO("   %s = %lu   %s = %lu   %s = %s",
					GET_NAME(state), (uint32_t)state,
					GET_NAME(event), (uint32_t)event,
					GET_NAME(b_event), (b_event ? "true" : "false"));
	}

	put_event_task_display(0, 0, "task_system_mode");
	put_event_task_display(0, 1, " NORMAL         ");

	task_system_set_mode(NORMAL);
}

void task_system_update(void *parameters)
{
	/* Run Task Statechart */
	switch (g_task_system_mode)
	{
		case NORMAL:

			task_system_normal_statechart();

			break;

		case SETUP:

			task_system_setup_statechart();

			break;

		default:

			task_system_set_mode(NORMAL);

			break;
		}
}

void task_system_set_mode(task_system_mode_t task_system_mode)
{
	g_task_system_mode = task_system_mode;
}

/********************** end of file ******************************************/
